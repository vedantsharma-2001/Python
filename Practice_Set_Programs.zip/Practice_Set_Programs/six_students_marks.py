m1 = int(input("Enter marks:"))
m2 = int(input("Enter marks:"))
m3 = int(input("Enter marks:"))
m4 = int(input("Enter marks:"))
m5 = int(input("Enter marks:"))
m6 = int(input("Enter marks:"))

student_marks = [m1,m2,m3,m4,m5,m6]
student_marks.sort()
print(student_marks)