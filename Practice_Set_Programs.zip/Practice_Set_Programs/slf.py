class Example:
    def __init__(slf,name):
        slf.name = name
    
    def printData(slf):
        print(f"Name : {slf.name}")
a = Example("Vedant")
a.printData()