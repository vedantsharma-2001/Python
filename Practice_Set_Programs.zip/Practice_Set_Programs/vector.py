class C2d:
    def __init__(self,i,j):
        self.i = i
        self.j = j

    def __str__(self):
        return f"{self.i}i+{self.j}j"

class C3d(C2d):
    def __init__(self,i,j,k):
        super().__init__(i,j) 
        self.k = k

    def __str__(self):
        return f"{self.i}i+{self.j}j+{self.k}k"

vector_2d = C2d(1,8)
vector_3d = C3d(10,20,30)
print("Vector of 2D :",vector_2d)
print("Vector of 3D :",vector_3d)