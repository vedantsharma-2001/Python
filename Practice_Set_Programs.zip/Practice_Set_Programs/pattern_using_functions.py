def pattern():
    for i in range(0,n):
        print("*\t" * (n-i))

n = 3
pattern()