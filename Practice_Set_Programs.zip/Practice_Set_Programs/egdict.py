favlang1 = {}

a = input("Enter your favourite language Vedant:")
b = input("Enter your favourite language Amrut:")
c = input("Enter your favourite language Sanket:")
d = input("Enter your favourite language Ayush:")

favlang1['Vedant'] = a
favlang1['Amrut'] = b 
favlang1['Sanket'] = c
favlang1['Ayush'] = d

print(favlang1)

favlang2 = {}

print("If name of 2 friends are same in keys,what it will print in output?")

a = input("Enter your favourite language Vedant:")
b = input("Enter your favourite language Amrut:")
c = input("Enter your favourite language Vedant:")
d = input("Enter your favourite language Ayush:")

 
favlang2['Vedant'] = a
favlang2['Amrut'] = b 
favlang2['Vedant'] = c
favlang2['Ayush'] = d

print(favlang2)

favlang3 = {}

print("If name of 2 languages are same in values,what it will print in output?")

a = input("Enter your favourite language Vedant:")
b = input("Enter your favourite language Amrut:")
c = input("Enter your favourite language Sanket:")
d = input("Enter your favourite language Ayush:")


favlang3['Vedant'] = a
favlang3['Amrut'] = b 
favlang3['Sanket'] = c
favlang3['Ayush'] = d

print(favlang3)