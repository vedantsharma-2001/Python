#Write a Python Program to find average of two numbers.

a=int(input("Enter the number:"))
b=int(input("Enter the number:"))

average=(a+b)/2

print(average)