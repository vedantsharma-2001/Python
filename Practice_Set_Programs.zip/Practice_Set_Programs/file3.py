for i in range(2,20+1):
    with open(f"tables/Multiplication Table of {i}.txt","w") as f:
        for j in range(1,10+1):
            f.write(f"{i}*{j}={i*j}")
            if j != 10:
                f.write("\n")