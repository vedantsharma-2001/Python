namelist = ["Sanskar","Ayush","Swapnil","Amrut"]

for name in namelist:
    if name.startswith("S"):
        print("Good Morning,",name)

    