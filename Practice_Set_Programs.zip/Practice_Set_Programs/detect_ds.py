str = "This is a string to detect double  spaces"
print(str.find("  "))