str = "This is a string to detect double  spaces"
str = str.replace("  "," ")
print(str)