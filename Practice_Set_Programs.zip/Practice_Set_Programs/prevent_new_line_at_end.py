def print_new_line():
    print("This is Vedant Sharma.",end="")
    print("This is Sanket Shivde.",end="")

print_new_line()