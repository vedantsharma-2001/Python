class Train:
    def __init__(self,tr_no,tr_name,seats,fare):
        self.tr_no = tr_no
        self.tr_name = tr_name
        self.seats = seats
        self.fare = fare

    def getStatus(self):
        print(f"Train Number : {self.tr_no}\nTrain Name : {self.tr_name}\nSeat Available : {self.seats}")
    
    def ticketbook(self):
        if(self.seats > 0):
            print(f"Your Tickets Has been Booked!Seat No is {self.seats}")
            self.seats = self.seats - 1
        else:
            print("No Seat Available")
    def cancelticket(self):
        seats = int(input("Enter seats to cancel:"))
        print(f"Cancelled")
        self.seats = self.seats + 1

a = Train(12018,"SHATABDI EXPRESS",2,680)
a.getStatus()
a.ticketbook()
a.ticketbook()
a.getStatus()
a.getStatus()
a.ticketbook()
a.cancelticket()
a.getStatus()