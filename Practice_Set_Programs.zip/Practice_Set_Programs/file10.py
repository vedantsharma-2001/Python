with open("content.txt","r") as f:
    data = f.read()

with open("content.txt","w") as f:
    delete = data.replace(data,"")
    print(delete)