class Employee:
    salary = 1000
    increment = 50
    
    @property
    def salaryAfterIncrement(self):
        return self.salary * self.increment
    
    @salaryAfterIncrement.setter
    def salaryAfterIncrement(self,val):
        self.increment = val / self.salary
    
a = Employee()
print(a.salary)
print(a.salaryAfterIncrement)
print(a.increment)
a.salaryAfterIncrement = 2000
print(a.increment)