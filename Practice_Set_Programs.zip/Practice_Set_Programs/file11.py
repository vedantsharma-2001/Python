import os
filename1 = "content.txt"
filename2 = "contentimportant.txt"
with open(filename1) as f:
    data = f.read()
os.replace(filename1,filename2)