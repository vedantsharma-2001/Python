class Animals:
    animaltype = "Dog"

class Pets(Animals):
    color = "White"

class Dog(Pets):
    def bark(self):
        print("Dog is Barking")

a = Animals()
b = Pets()
c = Dog()
c.bark()