linenumber = 0
word = "python"

with open("logfile.txt","r") as f:
    for line in f:
        linenumber = linenumber + 1
        if word in line.lower():
            print(f"The word {word} is present in line {linenumber}")
            break
    else:
        print("Word Not Found")