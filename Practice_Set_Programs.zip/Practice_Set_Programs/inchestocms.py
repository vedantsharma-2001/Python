def inch_to_cm():
    cm = 2.54 * inch
    return cm

inch = int(input("Enter inch:"))
print(inch,"inch =",inch_to_cm(),"cm")