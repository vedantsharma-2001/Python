s = {}
print("Type of s:",type(s))