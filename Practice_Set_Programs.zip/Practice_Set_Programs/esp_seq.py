letter = "Dear Harry, This Python Course is Helpful. Thanks!"
print("Letter:\n",letter)
formatted_letter = "Dear Harry, \n\tThis Python Course is Helpful.\nThanks!"
print("Formatted Letter:\n",formatted_letter)