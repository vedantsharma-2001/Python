s = set()
s.add(20)
s.add(20.0)
s.add("20")

print("Added items in the Set:",s)
print("Length of Set:",len(s))