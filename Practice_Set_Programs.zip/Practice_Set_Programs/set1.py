s = {8,7,12,"Harry",[1,2]}

print(s)