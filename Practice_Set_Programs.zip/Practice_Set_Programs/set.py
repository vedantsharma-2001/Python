s1 = {1,2,3,4,5}
print(type(s1))
print("Set:",s1)

s2 = {1,2,1,4,5}
print("Set:",s2)

a = {}
#This syntax will create an empty dictionary not an empty set.
print(type(a))

#An empty set can be created using the following syntax
b = set()
print(type(b))
b.add(1)
b.add(1)
b.add(2)
b.add((3,4,5))
print("Added Items in Set using add():",b)
#b.add([4:5]) #Cannot add list to sets.
#b.add({4:5}) #Cannot add dictonary to sets.
#Set Methods
set1 = {1,2,3,4,5}
set2 = {1,3,8,10,20}
print("Set:",set1)
print("Set:",set2)

print("Set len():",len(set1))
set1.remove(1)
print("Set remove():",set1)
set_pop = set1.pop()
print("Set pop():",set_pop)
set1.clear()
print("Set clear():",set1)
a1 = {1,2,3,5}
a2 = {4,5,6,8}
print("Set union():",a1.union(a2))
print("Set intersection():",a1.intersection(a2))