n = int(input("Enter the number:"))

fact = 1

print("Factorial Number using for loop")

for i in range(1,n+1):
    fact = fact * i
print("Factorial of",n,"is",fact)


print("Factorial Number using while loop")

a = 1
f = 1
while(a <= n):
    f = f * a
    a = a + 1
print("Factorial of",n,"is",f)