#Use Comparison operators to find out whether a given variable a is greater than b or not.
#Given Data:- a=34 and b=80

a=34
b=80

if(a>b):
   print("a is greater than b")
else:
   print("b is greater than a")

