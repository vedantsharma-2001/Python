n1 = int(input("Enter number:\n"))
n2 = int(input("Enter number:\n"))
n3 = int(input("Enter number:\n"))
n4 = int(input("Enter number:\n"))
n5 = int(input("Enter number:\n"))
n6 = int(input("Enter number:\n"))
n7 = int(input("Enter number:\n"))
n8 = int(input("Enter number:\n"))

s = {n1,n2,n3,n4,n5,n6,n7,n8}

print(s)