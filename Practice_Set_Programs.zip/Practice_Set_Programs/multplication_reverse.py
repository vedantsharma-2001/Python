n = int(input("Enter the number:"))
print("Multiplication of a table using for loop")
for i in range(10,0,-1):
    print(n," * ",i, " = ", n*i)
print("Multiplication of a table using while loop")
a = 10
while(a>=1):
    print(n," * ",a," = ",n*a)
    a = a - 1