import os.path
if os.path.isfile("file01.txt"):
    print("File 01 Present")
    with open("file01.txt","r") as f1:
        data1 = f1.read()
        print(data1)
else:
    print("File 01 Absent")

if os.path.isfile("file02.txt"):
    print("File 02 Present")
    with open("file02.txt","r") as f2:
        data2 = f2.read()
        print(data2)
else:
    print("File 02 Absent")

if os.path.isfile("file03.txt"):
    print("File 03 Present")
    with open("file03.txt","r") as f3:
        data3 = f3.read()
        print(data3)
else:
    print("File 03 Absent")