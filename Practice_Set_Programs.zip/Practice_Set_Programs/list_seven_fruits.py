f1 = input("Enter name:")
f2 = input("Enter name:")
f3 = input("Enter name:")
f4 = input("Enter name:")
f5 = input("Enter name:")
f6 = input("Enter name:")
f7 = input("Enter name:")

fruits_name = [f1,f2,f3,f4,f5,f6,f7]
print(fruits_name)