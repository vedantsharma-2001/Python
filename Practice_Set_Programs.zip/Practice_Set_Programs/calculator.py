import math
class calculator:
    def __init__(self,a,b,c):
        self.a = a
        self.b = b
        self.c = c
    
    def operations(self):
        print(f"Square of {self.a} is {self.a*self.a}")
        print(f"Cube of {self.b} is {self.b*self.b*self.b}")
        print(f"Square Root of {self.c} is {int(math.sqrt(self.c))}")
    @staticmethod
    def greet():
        print("Hello User")

a = int(input("Enter square:"))
b = int(input("Enter cube:"))
c = int(input("Enter Square Root:"))
ob = calculator(a,b,c)
ob.greet()
ob.operations()