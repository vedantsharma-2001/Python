words = ["Donkey","Zebra","Giraffe"]
with open("words.txt","r") as f:
    data = f.read()

for word in words:
    with open("words.txt","w") as f:
        data = data.replace(word,"######")
        f.write(data)