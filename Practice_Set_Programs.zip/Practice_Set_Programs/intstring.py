s = {18,"18"}
print(s)