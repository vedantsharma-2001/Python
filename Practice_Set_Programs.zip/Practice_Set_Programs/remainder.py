#Write a Python Program to find remainder when a number is by 2.

a=int(input("Enter the number:"))
b=int(input("Enter the number:"))

rem=a%b

print("Remainder of",a,"and",b,"is",rem)