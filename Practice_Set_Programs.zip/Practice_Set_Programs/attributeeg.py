class attributeeg:
    a = "Vedant"

object = attributeeg()
object.a = "Sanket"
print(attributeeg.a)
print(object.a)