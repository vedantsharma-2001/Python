username = input("Enter username:")

if(len(username) < 10):
    print("Error!!!Username cannot be less than 10 characters")
else:
    print("Correct Username")