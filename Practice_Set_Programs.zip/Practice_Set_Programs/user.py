name = input("Enter your name:")
print("Good Afternoon",name)