d = {"Bhaago":"Run","Desh":"Country","Dhup":"Sun"}

print("List of Hindi Words:\n",d.keys())

a = input("Enter the Hindi Word:\n")

#print("Translation of that Word in English is :",d[a])

#Below line will not throw an error if the key is not present in the dictionary
print("Translation of that Word in English is :",d.get(a))
