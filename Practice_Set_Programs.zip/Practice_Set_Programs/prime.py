n = int(input("Enter the number:"))
print("Prime Number using for loop")
flag = 0
if n == 1:
    print("It is not a composite number")

for i in range(2,n):
    if(n % i == 0):
        flag = 1
        break

if flag == 0:
    print("It is a prime number")
else:
    print("It is not a prime number")

print("Prime Number using while loop")
a = 2
p = 0
while(a<=n/2):
    if(n % a == 0):
        p = 1
        break
    a = a + 1

if(p == 0):
    print("It is a prime number")
else:
    print("It is not an prime number")

