a = "10"

#To Convert String to Int

str_to_int = int(a)

print("After Convert from String to Integer:",str_to_int)

#To Convert String to Float

str_to_float = float(a)

print("After Convert from String to Float:",str_to_float)


