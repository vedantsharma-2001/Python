class Employee:
    company = "Google"
    def getSalary(self,signature):
        print(f"Salary for employee working in {self.company} is {self.salary}\n{signature}")
    @staticmethod #decorator to mark greet as a static method
    def greet():
        print("Vedant Sharma")

a1 = Employee()
a1.salary = 200000
a1.getSalary("Thanks") #Employee.getSalary(a1)
a1.greet() #Employee.greet(a1)