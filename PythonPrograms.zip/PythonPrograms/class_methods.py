class Employee:
    company = "camel"
    salary = 100
    
    def changesalary1(self,sal):
        self.__class__.salary = sal #Changing Values of Class Attribute Salary using self.__class__.salary
    
    @classmethod
    def changesalary2(slf,sal):
        slf.salary = sal #Changing Values of Class Attribute Salary using decorator @classmethod
    #Decorator - It is used to take function as an input and modifys them.
a = Employee()
print(a.salary)
a.changesalary1(500) #Adding Instance Attribute in order to change the salary
print(a.salary) 
print(a.salary) 
print(Employee.salary)