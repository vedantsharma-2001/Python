try:
    n = int(input("Enter number:"))
    a = 1/n
    print(a)
except Exception as e:
    print("Sorry, not executed!!! Only numbers are allowed")
else:
    print("Executed")         #This is executed only if the try was successful