class Form:
    def printForm(self):
        print(f"Name:{self.name}")
        print(f"Place:{self.place}")

details = Form()
details.name = "Vedant Sharma"
details.place = "Pune"
details.printForm()