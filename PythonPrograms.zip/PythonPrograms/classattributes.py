class Employee:
    company = "Google"  #specific to each class
    #Class Attributes

a1 = Employee()  #object instantiation
a2 = Employee()  #object instantiation

print(a1.company)  
print(a2.company)

Employee.company = "Youtube"  #Changing Class Attributes

print(a1.company)  
print(a2.company)
