try:
    n = int(input("Enter number:"))
    a = 1/n
    print(a)
except Exception as e:
    print("Wrong Input!!! Only numbers are allowed")
    exit()
finally:
    print("Executed") #executed regardless of error

print("Done already")