import os
if os.path.exists("Vedant.txt"):
    os.remove("Vedant.txt")
else:
    print("This file does not exist")