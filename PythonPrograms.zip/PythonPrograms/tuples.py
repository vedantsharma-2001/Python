t1 = (10,2,34,5,10)
print("Tuple:",t1) #Printing the elements of the tuple
#t1[1] = 5 #Cannot Update the Values 
t2 = () #Empty Tuple
print("Empty Tuple:",t2)
#t3 = (1) #Wrong Way to Create Tuple with Single Element.
t3 = (1,)
print("Tuple with Single Element:",t3)
t4 = (1,5,8)
print("Tuples with more than one element:",t4)
#Tuples Methods
tuple_count = t1.count(10)
print("Tuple count():",tuple_count)
tuple_index = t1.index(2)
print("Tuple index():",tuple_index)