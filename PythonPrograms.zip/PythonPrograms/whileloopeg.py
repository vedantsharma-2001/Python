a = 1

while(a<=50):
    print(a)
    a = a + 1


b = [1,2,3,4,5]
i = 0

while(i<len(b)):
    print(b[i])
    i = i + 1


c = ["Vedant","Sanket","Amrut","Ayush"]
i = 0

while(i<len(c)):
    if(len(c[i])>5):
        print(c[i])
        i = i + 1


