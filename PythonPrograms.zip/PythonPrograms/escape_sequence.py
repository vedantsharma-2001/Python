a = "Bullet Trains run upto 300km per hr.\n It\tis considered as world\'s \\fastest trains"
print(a)