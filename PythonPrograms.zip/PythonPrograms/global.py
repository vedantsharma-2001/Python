a = 10 #Global Variable
def f1():
    global a
    print(f"Statment 1:{a}")
    a = 1 #Local Variable
    print(f"Statment 2:{a}")
f1()
print(f"Statment 3:{a}")