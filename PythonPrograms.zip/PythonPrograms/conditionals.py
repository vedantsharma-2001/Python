a = 8
#if-elif-else ladder
if(a>3):
    print("a is greater than 3")
elif(a>10):
    print("a is greater than 10")
elif(a>15):
    print("a is not greater than 15")
else:
    print("a is not greater than 13")

b = 8
#Multiple if statments
if(b>3):
    print("b is greater than 3")

if(b>10):
    print("b is greater than 10")

if(b>15):
    print("b is greater than 15")
else:
    print("b is not greater than 13")