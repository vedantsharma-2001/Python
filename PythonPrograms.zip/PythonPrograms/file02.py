import file01
file01.player("Lionel Messi")