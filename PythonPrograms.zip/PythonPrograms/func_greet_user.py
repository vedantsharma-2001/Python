def greet(user):
    print("Good Day",user)

greet("Vedant")