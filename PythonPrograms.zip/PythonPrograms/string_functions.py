str1 = "Superfast Express Trains runs too fast"
print("Length of str1:",len(str1))
print("String Endswith:",str1.endswith("fast"))
print("String Count:",str1.count("a"))
str2 = "python is an highly interpreted program language program"
print("String Capitalize:",str2.capitalize())
print("Find Word:",str2.find("program"))
print("String Replace:",str2.replace("program","programming"))