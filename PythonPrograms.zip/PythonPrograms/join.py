l = ["Vedant","Sanket","Ayush"]
join_sentence = ",".join(l)
print(join_sentence)