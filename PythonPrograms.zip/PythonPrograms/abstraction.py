from abc import ABC


class Shape(ABC):

    def area(self):
        pass
    
    def perimeter(self):
        pass
    

class Rectangle(Shape):
    def __init__(self,l,b):
        self.l = l
        self.b = b
    
    def area(self):
        return self.l*self.b
    
    def perimeter(self):
        return 2+self.l*2+self.b
        
a = Rectangle(10,10)
print(a.area())
print(a.perimeter())