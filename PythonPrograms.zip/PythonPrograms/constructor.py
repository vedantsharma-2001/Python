class Form:
    def __init__(self,name,age,place):
        self.name = name
        self.age = age
        self.place = place

    def details(self):
        print(f"Name:{self.name}, Age:{self.age}, Place:{self.place}")


a = Form("Vedant",10,"Pune")  #Object can be instantiated using constructor like this
a.details()