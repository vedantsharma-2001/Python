a = 'abc'
b = "abc"
c = '''abc'''
d = "abc's"
e = '''abc"s'''
print(a)
print(b)
print(c)
print(d)
print(e)

