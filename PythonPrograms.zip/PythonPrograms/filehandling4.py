with open("another.txt","r") as f:
    a = f.read()
print(a)

with open("another.txt","w") as f:
    f.write("Vedant Sharma")
print("Don't need to write f.close() as it is done automatically")