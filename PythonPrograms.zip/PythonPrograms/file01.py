def player(name):
    print(f"Player Name : {name}")
print(__name__)
if __name__ == "__main__":
    name = input("Enter player name:")
    player(name)