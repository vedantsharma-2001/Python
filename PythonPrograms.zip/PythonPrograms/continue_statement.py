for i in range(10):
    print(i)
    if(i==4):
        continue
    print(i)