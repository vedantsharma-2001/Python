class Employee:
    company = "Bitwise"
    salary = 100
    bonus = 100

    @property                             #Internally the function will be executed and its value will generate
    def totalSalary(self):
        return self.salary + self.bonus
    
    @totalSalary.setter
    def totalSalary(self, val):
        self.bonus = val - self.salary
            
a = Employee()
print(a.totalSalary)                      
a.totalSalary = 100
print(a.salary)
print(a.bonus)
#The method @property decorator is also called as getter method