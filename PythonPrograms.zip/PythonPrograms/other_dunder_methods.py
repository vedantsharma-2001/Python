class Examples:
    def __init__(self,num):
        self.num = num

    def __str__(self):
        return f"{self.num}"
    
    def __len__(self):
        return 1
    
n1 = Examples(10)
print(n1)
print(len(n1))