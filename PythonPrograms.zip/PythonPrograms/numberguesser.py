import random
class numberguess:
    def __init__(self,number):
        self.guess = 0
        self.number = number
        self.guessnumber = random.randint(1,10)
        
        while(self.number != self.guessnumber):
            n = int(input("Enter the number:"))
            self.guess = self.guess + 1
            if(n == self.guessnumber):
                print("It is correct")
                break
            else:
                if(n > self.guessnumber):
                    print("Lower Number Please")
                else:
                    print("Higher Number Please")
                    
    def __str__(self):
        return f"Total Guessed : {self.guess}"
        
n = None
a = numberguess(n)
print(a)