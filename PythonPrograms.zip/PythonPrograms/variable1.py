a = 10
b = 10.10
c = "abc"
d = True
d = False

print(a,type(a))
print(b,type(b))
print(c,type(c))
print(d,type(d))


