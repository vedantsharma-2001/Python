a = "Vedant"

print(a[0:6])
print(a[:6]) #It is same as your a[0:6]
print(a[0:]) #It is same as your a[0:6]


#Negative Indexing

print(a[-6:]) #It is same as your a[0:6]

#Skip Value for Slicing
print(a[1:5:2])