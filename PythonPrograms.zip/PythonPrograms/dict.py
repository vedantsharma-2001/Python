d1 = {"Roll No" : 1,
      "Name" : "Vedant",
      "Place":"Nigdi",
      "Pincode" : {411044 : "Pune"}} 

print("Dictionary:",d1)
d1["Roll No"] = 101
print(d1["Roll No"])
print(d1["Name"])
print(d1["Place"])
print(d1["Pincode"][411044])

#Dictionary Methods

print("Dictionary:",d1)
d1.items()
print("Dictionary items():",d1)
dictkeys = d1.keys()
print("Dictionary keys():",dictkeys)
d1.update({"Place":"Patna"})
print("Dictionary update():",d1)
print("Dictionary get():",d1.get("Name"))

print(d1.get("Name")) #Prints value assosciated with key Harry
print(d1["Name"]) #Prints value assosciated with key Harry

# Difference between .get() and [] 
print(d1.get("Name2")) #Returns None as Name2 is not present in dictionary.
print(d1["Name2"]) #Throws an error as Name2 is not present in dictionary.