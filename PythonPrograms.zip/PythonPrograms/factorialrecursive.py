def factorial(n):
    if n == 0 or n == 1: #Base Condition which doesn't call the function any further
        return 1
    else:
        return n*factorial(n-1) #Function Calling Itself

n = int(input("Enter the factorial:"))
fact = factorial(n)
print(fact)