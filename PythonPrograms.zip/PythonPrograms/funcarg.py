def funcname1(fname): #defining a function
    print(fname,"Sharma")

funcname1("Vedant")
funcname1("Ekta")
funcname1("Richa")
funcname1("Ravi")

def funcname2(fname,mname,lname): #defining a function
    print(fname,mname,lname)

funcname2("Sanket","Venkatesh","Shivde") #calling a function
funcname2("Sanskar","Manohar","Wagavkar") #calling a function

