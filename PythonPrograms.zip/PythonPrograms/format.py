state = "California"
capital = "Sacramento"
country = "USA"

a = "{} is the state capital of {} situated in {}".format(capital,state,country)
print(a)