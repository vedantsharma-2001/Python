try:
    n = int(input("Enter the number:"))
    a = 1/n
    print(a)
    b = 1/str(n)
    print(b)
except ValueError as a1:
    print(a1)

except ZeroDivisionError as a2:
    print(a2)

except TypeError as a3:
    print(a3)