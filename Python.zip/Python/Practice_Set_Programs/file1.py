f=open("poems.txt")
data = f.read()
if 'Twinkle' in data:
    print("It is Present")
else:
    print("It is Absent")

f.close()