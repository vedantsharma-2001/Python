with open("words.txt","r") as f:
    data = f.read()

if 'Donkey' in data:
    with open("words.txt","w") as f:
        wordreplace = data.replace("Donkey","######")
        f.write(wordreplace)