text = input("Enter the text:")

if("Make a lot of money" in text):
    spam = True
else:
    spam = False

if("Buy now" in text):
    spam = True
else:
    spam = False

if("Subscibe this" in text):
    spam = True
else:
    spam = False

if("Click this" in text):
    spam = True
else:
    spam = False

if(spam):
    print("This is a spam")
else:
    print("This is not a spam")