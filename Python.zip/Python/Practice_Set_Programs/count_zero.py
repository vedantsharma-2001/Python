a = (7,0,8,0,0,9)
total_count = a.count(0)
print("total count of zeros:",total_count)