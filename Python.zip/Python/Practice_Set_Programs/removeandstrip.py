def removeandstrip(string,word):
    s1 = string.replace(word,"")
    return s1.strip()

line = "  The Plane is flying too fast"
s2 = removeandstrip(line,"flying")
print(s2)