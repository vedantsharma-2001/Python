def greatest(a,b,c):
    if a>b and a>c:
        print("a is greater")
        return a
    elif b>a and b>c:
        print("b is greater")
        return b
    elif c>a and c>b:
        print("c is greater")
        return c

a=int(input("Enter number:"))
b=int(input("Enter number:"))
c=int(input("Enter number:"))

print(greatest(a,b,c))