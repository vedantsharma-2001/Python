s1=int(input("Enter marks:"))
s2=int(input("Enter marks:"))
s3=int(input("Enter marks:"))

if(s1 < 33 or s2 < 33 or s3 < 33):
    print("Due to Failing in Subjects")
elif((s1+s2+s3)/3 < 40):
    print("Fail")
else:
    print("Pass")