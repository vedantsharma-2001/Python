#Check the type of the variable assigned using input() function.

a = input("Enter Place:")

print("Type of Variable:",type(a))

