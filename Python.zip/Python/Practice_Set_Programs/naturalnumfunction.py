def natural_numbers():
    sum = 0
    for i in range(1,n+1):
        sum = sum + i
    return sum

n = int(input("Enter the natural numbers:"))
print("The First",n,"natural numbers are",natural_numbers())
