#Write a Python Program to add two numbers.

a=int(input("Enter the number:"))
b=int(input("Enter the number:"))

add=a+b

print("Addition of",a,"and",b,"is",add)

