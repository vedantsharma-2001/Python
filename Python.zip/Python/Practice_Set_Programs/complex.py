#(a+bi)(c+di) = (ac-bd)(ad+bc)
class Complex:
    def __init__(self,real,imaginary):
        self.real = real
        self.imaginary = imaginary
    
    def __add__(self,complex):
        return Complex(self.real + complex.real , self.imaginary + complex.imaginary)
    
    def __mul__(self,complex):
        real_numbers = self.real*complex.real - self.imaginary*complex.imaginary
        imaginary_numbers = self.real*complex.imaginary + self.imaginary*complex.real
        return Complex(real_numbers,imaginary_numbers)
    
    def __str__(self):
        return f"{self.real} + {self.imaginary}i"
    
a = Complex(3,2)
b = Complex(1,7)
print(a+b)
print(a*b)