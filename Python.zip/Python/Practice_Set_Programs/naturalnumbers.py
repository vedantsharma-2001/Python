n = int(input("Enter the number:"))

print("Natural Numbers using for loop")

sum = 0

for i in range(1,n+1):
    sum = sum + i
print("The First",n,"Natural Numbers is ",sum)

print("Natural Numbers using while loop")

a = 1
s = 0

while(a <= n):
    s = s + a
    a = a + 1
print("The First",n,"Natural Numbers is ",s)

print("Natural Numbers using formula")

formula = (n*(n+1))//2

print("The First",n,"Natural Numbers is ",formula)

