l1 = [1,5,20,68,3,88,"abc",4.0]
for i,item in enumerate(l1):
    if i == 3 or i == 5 or i == 7:
        print(f"{item}")