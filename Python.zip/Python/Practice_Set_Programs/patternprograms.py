''' 
    *
  * * *
* * * * *
n1 = 3
'''
n1 = 3

for i in range(0,n1):
        print(" " * (n1-i-1),end="")
        print("*" * (2*i+1),end="")
        print(" " * (n1-i-1))

''' 
*
* * 
* * * 
n2 = 3
'''
n2 = 3

for i in range(0,n2):
    for j in range(0,i+1):
        print("*",end="")
    print("")

'''
* * *
*   *
* * *
n3 = 3
'''
'''
n3 = 3
for i in range(n3):
     for j in range(n3):
          if i == 1 or j == 1:
               print(" ",end="")
          else:
               print("*",end="")
     print("")
'''