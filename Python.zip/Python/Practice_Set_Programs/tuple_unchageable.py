t = (1,6,20,21)
print("Tuple:",t)
t[1] = 8 #Tuple cannot be changed
print(t)