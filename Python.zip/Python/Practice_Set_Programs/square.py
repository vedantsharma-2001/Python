#Write a Python Program to Calculate Square of a number entered by the user.

a=int(input("Enter the square:"))

square = a*a

print("The square of",a,"is",square)



