text = input("Enter the text:")
print("You Typed\n",text)

if('Harry' in text):
    print("Yes given post is talking about Harry")
else:
    print("No the given post is not talking about Harry")