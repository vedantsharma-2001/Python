def multiplication():
    for i in range(1,10+1):
        print(n,"*",i,"=",n * i)

n = int(input("Enter the number:"))
multiplication()