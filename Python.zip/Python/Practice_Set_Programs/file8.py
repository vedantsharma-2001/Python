with open("logfile.txt","r") as f:
    data = f.read()

with open("copy.txt","w") as file:
    file.write(data)