a = [1,5,10,13]
print("List:",a)
print("Sum of List:",a[0]+a[1]+a[2]+a[3])
