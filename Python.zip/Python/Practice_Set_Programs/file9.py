with open("logfile.txt","r") as f1:
    d1 = f1.read()
    print("---logfile.txt---")
    print(d1)

with open("copy.txt","r") as f2:
    d2 = f2.read()
    print("---copy.txt---")
    print(d2)

if(d1 == d2):
    print("Files are Identical")
else:
    print("Files are not Identical")