n = int(input("Enter the number:"))
print("Multiplication of a table using for loop")
for i in range(1,10+1):
    print(n," * ",i, " = ", n*i)
print("Multiplication of a table using while loop")
a = 1
while(a<=10):
    print(n," * ",a," = ",n*a)
    a = a + 1