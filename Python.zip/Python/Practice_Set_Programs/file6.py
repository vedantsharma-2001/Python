with open("logfile.txt","r") as f:
    data = f.read()

if 'python' in data.lower():
    print("The word Python contains in the file")
else:
    print("The word Python does not contains in the file")