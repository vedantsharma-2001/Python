class Vector:
    def __init__(self,vector):
        self.vector = vector
    
    def __str__(self):
        str1 = ""
        index = 0
        for i in self.vector:
            str1 = str1 + f" {i}a{index} +"
            index = index + 1
        return str1[:-1]
    
    def __add__(self,vector2):
        newlist = []
        for i in range(len(self.vector)):
            newlist.append(self.vector[i] + vector2.vector[i])
        return Vector(newlist)
    
    def __mul__(self,vector2):
        sum = 0
        for i in range(len(self.vector)):
            sum = sum + self.vector[i]*vector2.vector[i]
        return sum
    
    def __len__(self):
        return len(self.vector)
    
v1 = Vector([1,2,3])
v2 = Vector([3,4,5])
print(v1+v2)
print(v1*v2)
print("Total Dimension of Vector 1 : ",len(v1))
print("Total Dimension of Vector 2 : ",len(v2))
