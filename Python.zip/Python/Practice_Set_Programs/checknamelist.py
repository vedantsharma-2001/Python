name = ["Car","Bus","Aeroplane"]

name_search = input("Enter the name to be found in the list:")

if(name_search in name):
    print("Name you have entered is Present in the List")
else:
    print("Name you have entered is Absent in the List")