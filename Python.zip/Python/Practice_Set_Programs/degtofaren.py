def deg_to_faren(deg_c):
    return (deg_c*(9/5)+32)

deg_c = int(input("Enter the degree celsius:"))
farenheit = deg_to_faren(deg_c)
print(deg_c,"Degree Celsius =",farenheit, "Farenheit")