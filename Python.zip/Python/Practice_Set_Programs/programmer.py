class Programmer:
    company = "Microsoft"
    def __init__(self,name):
        self.name = name

    def details(self):
        print(f"{self.name}")

name1 = Programmer("Vedant")
name2 = Programmer("Sanket")
name3 = Programmer("Ayush")
name1.details()
name2.details()
name3.details()