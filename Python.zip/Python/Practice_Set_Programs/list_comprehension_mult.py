n = int(input("Enter Multiplication:"))
mult = [n*i for i in range(1,10+1)]
print(mult)