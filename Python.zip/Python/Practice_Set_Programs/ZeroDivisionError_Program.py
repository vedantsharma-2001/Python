try:
    a = int(input("Enter the number:"))
    b = int(input("Enter the number:"))
    div = a/b
    print(div)
except ZeroDivisionError as a1:
    print("Infinite, ", a1)