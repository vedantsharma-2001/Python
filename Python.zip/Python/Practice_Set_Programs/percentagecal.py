s1=int(input("Enter marks:"))
s2=int(input("Enter marks:"))
s3=int(input("Enter marks:"))

percentage = (s1+s2+s3)/3
if(percentage < 50):
    print("Grade : F\n","Percentage:",percentage)
elif(percentage > 50 and percentage < 60):
    print("Grade : D\n","Percentage:",percentage)
elif(percentage > 60 and percentage < 70):
    print("Grade : C\n","Percentage:",percentage)
elif(percentage > 70 and percentage < 80):
    print("Grade : B\n","Percentage:",percentage)
elif(percentage > 80 and percentage < 90):
    print("Grade : A\n","Percentage:",percentage)
elif(percentage > 90 and percentage < 100):
    print("Grade : Ex\n","Percentage:",percentage)
