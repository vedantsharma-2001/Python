for i in range(20):
    print(i)
else:
    print("Done")