class Remote:
    pass

class Player:
    def moveLeft(self):    # |
        pass               # |
                           # | function methods inside the player is an example of encapsulation  
    def moveRight(self):   # |
        pass               # |

remote = Remote()
player = Player()

if(remote.isLeftPressed()):  #isLeftPressed() is layer of abstraction
    player.moveLeft()