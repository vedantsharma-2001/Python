i=4
if i > 0:
    pass
print("Done")

a = [1,2,3]

for i in a:
    pass
print("Done")