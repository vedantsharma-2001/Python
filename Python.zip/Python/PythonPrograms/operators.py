a=10
b=10

print("======Arithmetic Operators======")
print("Addition of",a,"and",b,"is",a+b)
print("Subtraction of",a,"and",b,"is",a-b)
print("Multiplication of",a,"and",b,"is",a*b)
print("Division of",a,"and",b,"is",a/b)

print("======Assignment Operators======")
print("a:",a)
a+=10
b-=10
print("Increment:",a)
print("Decrement:",b)

print("======Comparison Operators======")
if(a==b):
   print("Both are Equal")

if(a>b):
   print("a is greater than b")
 
if(a<b):
   print("a is lesser than b")

if(a>=b):
   print("a is greater than equal to b")

if(a<=b):
   print("a is lesser than equal to b")

if(a!=b):
  print("False")
else:
  print("True")

print("======Logical Operators======")
bool1=True
bool2=False

print("The value of bool1 and bool2 is:",bool1 and bool2)
print("The value of bool1 or bool2 is:",bool1 or bool2)
print("The value of not bool2 is:",not bool2)

