a = ["Vedant","Sanket","Amrut","Ayush"]

for i in a:
    print(i)