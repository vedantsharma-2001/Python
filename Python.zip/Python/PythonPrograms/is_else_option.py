a = int(input("Enter the number:"))

if(a == 6):
    print("Yes")
elif(a > 30):
    print("No and Yes")
else:
    print("I am optional")