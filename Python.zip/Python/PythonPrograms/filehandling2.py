#f=open("another.txt","w")
#f.write("This is USA")#Can be called multiple times
#write():- The write() function is used to write the specified text to the file.
f=open("another.txt","a")
f.write("I am appending")
#"a" for appending is used to add the contents at the end of the file.
f.close()