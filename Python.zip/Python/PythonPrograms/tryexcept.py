while(True): 
    print("Press q to quit the game")
    a = input("Enter the number:")
    if a == 'q':
        break
    try:
       a = int(a)
       if a<5:
          print("You Entered less than 5")
       elif a == 5:
          print("You Entered equal to 5")
       elif a>5:
          print("You Entered more than 5")
    except Exception as e:
        print(f"Your input has resulted an error:\n{e}")