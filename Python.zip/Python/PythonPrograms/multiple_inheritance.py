class Parent1:
    typeparent = "Father"
    def print(self):
        print(self.typeparent)
    
class Parent2:
    typeparent = "Mother"
    def print(self):
        print(self.typeparent)
       
class Child(Parent1,Parent2):
    typechild = "Son"
    #typeparent = "Father"
    def print(self):
        print(self.typechild)

a = Parent1()
b = Parent2()    
c = Child()
a.print()
b.print()
c.print()
#print(a.name)
#print(b.name)
print(c.typeparent)