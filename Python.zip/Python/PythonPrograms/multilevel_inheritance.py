class A:
    name = "A"
    def print(self):
        print(self.name)

class B(A):
    anothername1 = "B"
    #name = "A"
    def print(self):
        print(self.anothername1)

class C(B):
    anothername2 = "C"
    #name = "B"
    def print(self):
        print(self.anothername2)

a = A()
b = B()
c = C()

a.print()
b.print()
c.print()

#print(a.name)
print(b.name)
print(c.name)