l1 = [1,2,3,"Vedant","Sanket",4.0]
index1 = 0
for item1 in l1:
    print(f"{index1} : {item1}")
    index1 = index1 + 1
print("By Using Enumerate Function")
for index2,item2 in enumerate(l1):
    print(f"{index2} : {item2}") #Prints the items of list1 with index