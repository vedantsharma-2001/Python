#This example is same as Single Inheritance.

class Employee:               #Base Class or Parent Class
    company = "Google"
    def details(self):
        print(f"The Company is {self.company}")

class Programmer(Employee):   #Derived Class or Child Class
    language = "Python"
    #company = "YouTube"
    def details(self):
        print(f"The Language is {self.language}")
    

a = Employee()
b = Programmer()
a.details()
b.details()
#print(a.company)
print(b.company)