try:
   n = int(input("Enter number:"))
   print(n)
except:
   raise ValueError("Only numbers are allowed")