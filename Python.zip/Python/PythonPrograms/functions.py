def percent1(marks_list1):
    return ((sum(marks_list1)+18)/600)*100

def percent2(marks_list2):
    return (sum(marks_list2)/650)*100

marks1 = [45,54,70,60,51,62]
percentage1 = percent1(marks1)
print("Percentage:",percentage1)

marks2 = [46,35,36,36,51,74,46]
percentage2 = percent2(marks2)
print("Percentage:",percentage2)

