a = None
if(a is None):
    print("Yes")
else:
    print("No")
    
b = [10,20,30]
if(10 in b):
    print("It is Present in the List")
else:
    print("It is Absent in the List")
