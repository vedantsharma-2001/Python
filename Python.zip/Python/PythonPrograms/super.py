class A:
    letter1 = "A"
    def __init__(self):
        super().__init__()
        print("Intializing Letter A")
    def letter(self):
        print(f"Letter : {self.letter1}")

class B(A):
    letter2 = "B"
    def __init__(self):
        super().__init__()
        print("Intializing Letter B")
    def letter(self):
        super().letter()   #Calls constructor of base class
        print(f"Letter : {self.letter2}")
    
class C(B):
    letter3 = "C"
    def __init__(self):
        super().__init__()
        print("Initializing Letter C")
    def letter(self):
        super().letter()  #Calls constructor of base class
        print(f"Letter : {self.letter3}")
    
a = A()
b = B()
c = C()

a.letter()
b.letter()
c.letter()
