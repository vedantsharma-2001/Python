age = int(input("Enter the age:"))

if(age>=18):
    print("Yes")
else:
    print("No")