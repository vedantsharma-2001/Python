class Smartphone:
    def __init__(self,brand,os):
        self.brand = brand
        self.os = os

iphone = Smartphone("Apple","iOS")
iphone.os = "Android"
print(iphone.os)