#Use open function to read the content of a file
f = open("sample.txt","r")#opens the file in r mode
f1 = open("sample.txt") #by default the mode is r
f2 = open("sample.txt","r")
data = f.read()#Reads its contents
data2 = f1.read()#Reads its contents
data3 = f2.read(2)#Reads first 2 characters from a file
print(data)#Prints its contents
print(data2)#Prints its contents
print(data3)
f.close()#Closes the File