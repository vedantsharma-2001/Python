import modulename

a = modulename.data["age"]

print(a)

