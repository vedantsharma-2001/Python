i = 10
while(i<30):
    print(i,":","Yes")
    i = i + 1