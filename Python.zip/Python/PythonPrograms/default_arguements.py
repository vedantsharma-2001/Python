def funcname3(name = "stranger"):
    print(name)

    
funcname3() #Name will be used stranger in the function body(default)
funcname3("Vedant") #Name will be used Vedant in the function body(passed)