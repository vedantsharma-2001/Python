l1 = [1,4,2,5,6,3,4,5,8,4,3]

l2 = []
for item in l1:
    if item%2==0:
        l2.append(item)
print(l2)

print("By Using List Comprehension")
l3 = [i for i in l1 if i % 2 == 0]
print(l3)