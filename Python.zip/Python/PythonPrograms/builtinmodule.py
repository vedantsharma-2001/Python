import time
x = time.strftime('%d/%m/%Y,%H:%M:%S')
print(x)