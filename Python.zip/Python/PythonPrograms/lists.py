l1 = [1,10,24,45,60,10]
print("List:",l1)
print("The element present in the 2nd index is",l1)
l1[2] = 22 #To change the value
print("After replacing the element from 2nd position")
print(l1)

#We can create a list items with different types
l2 = [1,"abc",True,1.1]
print(l2)

#List Slicing
l3 = ["Amrut","Sanket","Vedant","Ayush",20]
print("List:",l3)
print("List Slicing:",l3[0:4])
print("List Slicing:",l3[-5:-1]) #Same as l3[0:4]
print("List Slicing:",l3[0:5])
print("List Slicing:",l3[-5:]) #Same as l3[0:] and l3[0:5]

#Lists Methods
l4 = [10,2,45,30,42]
print("List:",l4)
l4.append(100)
print("List append():",l4)
clear_list = l4.clear()
print("List clear():",clear_list)
copy_list = l4.copy()
print("List copy():",copy_list)
l5 = [10,30,40,50,60]
l6 = [70,80,90,100,110,120,10]
print("List:",l5)
print("List:",l6)
l5.extend(l6)
print("List extend():",l5)
l5.insert(1,20)
print("List insert():",l5)
list_index = l5.index(20)
print("List index():",list_index)
list_pop = l5.pop(3)
print("List pop():",list_pop)
l5.remove(30)
print("List remove():",l5)
l5.reverse()
print("List reverse():",l5)
list_sort = [30,5,13,4,20]
print("List:",list_sort)
list_sort.sort()
print("List sort():",list_sort)
list_count = l5.count(10)
print("List count():",list_count)