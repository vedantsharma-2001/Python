f=open("sample1.txt","r")
data=f.readline()#Reads one line from a file
print(data)
data=f.readline()#Reads second line from a file
print(data)
f.close()