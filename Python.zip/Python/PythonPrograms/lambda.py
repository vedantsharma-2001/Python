import math
while(True):
    x = input("Enter x number:")
    a = input("Enter a number:")
    b = input("Enter b number:")

    if x == 'q' or a == 'q'or b == 'q' :
        break


    x = int(x)
    a = int(a)
    b = int(b)
    cube = lambda x : x*x*x
    square = lambda x : x*x
    squareroot = lambda x : math.sqrt(x)
    add = lambda a,b : a+b
    sub = lambda a,b : a-b
    mult = lambda a,b : a*b
    div = lambda a,b : a/b
    print(f"Cube of {x} = {cube(x)}")
    print(f"Square of {x} = {square(x)}")
    print(f"Square Root of {x} = {squareroot(x)}")
    print(f"Addition of {a}+{b}={add(a,b)}")
    print(f"Subtraction of {a}-{b}={sub(a,b)}")
    print(f"Multiplication of {a}*{b}={mult(a,b)}")
    print(f"Division of {a}/{b}={div(a,b)}")