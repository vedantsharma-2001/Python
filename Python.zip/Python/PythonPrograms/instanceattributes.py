class Employee:  
    salary = 100 #specific to each class
    #Class Attributes


a1 = Employee()  #object instantiation
a2 = Employee()  #object instantiation

print(a1.salary)  
print(a2.salary)

#a1.salary = 200  #Creating an instance attribute of an object
#a2.salary = 300  #Creating an instance attribute of an object
a1.salary = 10  #Creating an new instance variable or new instance attribute
print(a1.salary)  
print(a2.salary)
#print(a1.address)  #throws an error as address is not present in instance/class attribute