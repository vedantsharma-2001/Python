age = int(input("Enter age:"))

if(age >= 20 and age <= 58):  #and - true if both operands are true else false
    print("You are allowed to Work")
else:
    print("You are not allowed to Work")

if(age >= 20 or age <= 58): #or - true if at least one operand are true else false
    print("You are allowed to Work")
else:
    print("You are not allowed to Work")

x = False

print(not x) #not - inverts true to false and false to true

